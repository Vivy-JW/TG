---
title: "6.3.2.6 Local Variables（Ctrl+L）"
source: "TOP GP技术手册.pdf#page=171"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.6 Local Variables（Ctrl+L）"
type: "concept"
description: "由TopMenu上的View选项进入Local Variables。"
pages: "171"
printed_pages: "162"
---

# 6.3.2.6 Local Variables（Ctrl+L）

由TopMenu上的View选项进入Local Variables。这里会列出所有此Function中所有的变量及当前的变量值。

## 图示

![6.3.2.6 Local Variables（Ctrl+L）（PDF 第 171 页 图 1）](../_images/p0171-02.png)

*图：6.3.2.6 Local Variables（Ctrl+L），原文 PDF 第 171 页（印刷第 162 页）*

![6.3.2.6 Local Variables（Ctrl+L）（PDF 第 171 页 图 2）](../_images/p0171-03.png)

*图：6.3.2.6 Local Variables（Ctrl+L），原文 PDF 第 171 页（印刷第 162 页）*
