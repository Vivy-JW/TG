---
title: "6.3.1.1 Execute Debugger Command（Ctrl+D）"
source: "TOP GP技术手册.pdf#page=169"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.1 Run选项 > 6.3.1.1 Execute Debugger Command（Ctrl+D）"
type: "concept"
description: "由TopMenu上的Run选项进入Execute Debugger Command。"
pages: "169"
printed_pages: "160"
---

# 6.3.1.1 Execute Debugger Command（Ctrl+D）

由TopMenu上的Run选项进入Execute Debugger Command。可以在此字段中输入其它 debug 指令；按下『Show all commands』会出现所有可用的指令列表，并叙述每个指令的功能。
