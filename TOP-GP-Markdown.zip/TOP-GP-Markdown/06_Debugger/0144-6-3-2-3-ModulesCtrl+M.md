---
title: "6.3.2.3 Modules（Ctrl+M）"
source: "TOP GP技术手册.pdf#page=170"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.3 Modules（Ctrl+M）"
type: "concept"
description: "由TopMenu上的View选项进入Modules。"
pages: "170"
printed_pages: "161"
---

# 6.3.2.3 Modules（Ctrl+M）

由TopMenu上的View选项进入Modules。这里会列出所有此程序中用到的4gl程序。
