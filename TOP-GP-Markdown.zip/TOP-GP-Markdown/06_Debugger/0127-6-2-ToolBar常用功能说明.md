---
title: "6.2 ToolBar常用功能说明"
source: "TOP GP技术手册.pdf#page=166"
breadcrumb: "6 Debugger > 6.2 ToolBar常用功能说明"
type: "concept"
description: "图形模式下的debugger功能较文字模式繁复，以下分功能进行简单的说明："
pages: "166"
printed_pages: "157"
---

# 6.2 ToolBar常用功能说明

图形模式下的debugger功能较文字模式繁复，以下分功能进行简单的说明：

## 子主题

- [6.2.1 Find... 搜寻](0128-6-2-1-Find-搜寻.md)
- [6.2.2 Find Next（F3）](0129-6-2-2-Find-NextF3.md)
- [6.2.3 Restart重新开始](0130-6-2-3-Restart重新开始.md)
- [6.2.4 Run/Cont 执行或继续程序](0131-6-2-4-RunCont-执行或继续程序.md)
- [6.2.5 Step Into 对每一程序行进行除错](0132-6-2-5-Step-Into-对每一程序行进行除错.md)
- [6.2.6 Step Over 对主程序每一行程序进行除错](0133-6-2-6-Step-Over-对主程序每一行程序进行除错.md)
- [6.2.7 Step Out 将此function执行完毕并回传结果](0134-6-2-7-Step-Out-将此function执行完毕并回传结果.md)
- [6.2.8 To Cursor 除错时会跳到当前cursor所在位置再开始debug](0135-6-2-8-To-Cursor-除错时会跳到当前cursor所在位置再开始debug.md)
- [6.2.9 Inspect 查看变数值](0136-6-2-9-Inspect-查看变数值.md)
- [6.2.10 Toggle 设定debug追踪点](0137-6-2-10-Toggle-设定debug追踪点.md)
