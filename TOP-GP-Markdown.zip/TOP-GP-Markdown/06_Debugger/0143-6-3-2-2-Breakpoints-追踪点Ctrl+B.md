---
title: "6.3.2.2 Breakpoints 追踪点（Ctrl+B）"
source: "TOP GP技术手册.pdf#page=170"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.2 Breakpoints 追踪点（Ctrl+B）"
type: "concept"
description: "由TopMenu上的View选项进入Breakpoints。"
pages: "170"
printed_pages: "161"
---

# 6.3.2.2 Breakpoints 追踪点（Ctrl+B）

由TopMenu上的View选项进入Breakpoints。列出此程序中的所有追踪点，并可在此设定追踪点是否启用。选择不启用的话，在程序中会看到Breakpoint呈现空心红圈的状态，此时只是暂时取消此追踪点不除错，若要将追踪点删除则使用下方功能键-『Delete breakpoint』或『Delete All』。『Jump To』功能可让程序直接跳到列表所选择（Highlight列）的追踪点位置。

『Add breakpoint』此功能会另跳出一个窗口让用户输入function name作为追踪点，若不清楚此程序内有哪些function，可用『Browse Functions』功能，列出所有function。

以上Breakpoints的部分功能也可以在TopMenu上的Breakpoints选项找到。
