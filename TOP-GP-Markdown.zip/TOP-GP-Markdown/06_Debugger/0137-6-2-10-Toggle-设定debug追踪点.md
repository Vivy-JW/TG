---
title: "6.2.10 Toggle 设定debug追踪点"
source: "TOP GP技术手册.pdf#page=168"
breadcrumb: "6 Debugger > 6.2 ToolBar常用功能说明 > 6.2.10 Toggle 设定debug追踪点"
type: "concept"
description: "（F9）在鼠标所选的行数按下Toggle，会在行前面加上红色实心圆，代表此行已被设定为追踪点。"
pages: "168"
printed_pages: "159"
---

# 6.2.10 Toggle 设定debug追踪点

（F9）在鼠标所选的行数按下Toggle，会在行前面加上红色实心圆，代表此行已被设定为追踪点。也可在程序行上双按鼠标左键设定Breakpoint。

## 图示

![6.2.10 Toggle 设定debug追踪点（PDF 第 168 页 图 1）](../_images/p0168-03.png)

*图：6.2.10 Toggle 设定debug追踪点，原文 PDF 第 168 页（印刷第 159 页）*
