---
title: "6.2.8 To Cursor 除错时会跳到当前cursor所在位置再开始debug"
source: "TOP GP技术手册.pdf#page=167"
breadcrumb: "6 Debugger > 6.2 ToolBar常用功能说明 > 6.2.8 To Cursor 除错时会跳到当前cursor所在位置再开始debug"
type: "concept"
description: "（F4）当debug开始时，若希望有某些程序段不需一行行追踪，将鼠标移动到下面某行程序段，按下To Cursor，就会跳过中间程序段直接由指定的那一行再度开始debug。"
pages: "167"
printed_pages: "158"
---

# 6.2.8 To Cursor 除错时会跳到当前cursor所在位置再开始debug

（F4）当debug开始时，若希望有某些程序段不需一行行追踪，将鼠标移动到下面某行程序段，按下To Cursor，就会跳过中间程序段直接由指定的那一行再度开始debug。
