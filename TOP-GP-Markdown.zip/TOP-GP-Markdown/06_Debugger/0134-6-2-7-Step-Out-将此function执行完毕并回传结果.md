---
title: "6.2.7 Step Out 将此function执行完毕并回传结果"
source: "TOP GP技术手册.pdf#page=167"
breadcrumb: "6 Debugger > 6.2 ToolBar常用功能说明 > 6.2.7 Step Out 将此function执行完毕并回传结果"
type: "concept"
description: "（Shift-F11）若不想继续debug此function的每一行程序段，可执行此功能将此function跑完。"
pages: "167"
printed_pages: "158"
---

# 6.2.7 Step Out 将此function执行完毕并回传结果

（Shift-F11）若不想继续debug此function的每一行程序段，可执行此功能将此function跑完。
