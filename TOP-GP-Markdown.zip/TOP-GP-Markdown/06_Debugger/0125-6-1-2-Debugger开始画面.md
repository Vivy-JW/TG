---
title: "6.1.2 Debugger开始画面"
source: "TOP GP技术手册.pdf#page=165"
breadcrumb: "6 Debugger > 6.1 Debugger操作画面 > 6.1.2 Debugger开始画面"
type: "concept"
pages: "165"
printed_pages: "156"
---

# 6.1.2 Debugger开始画面

Genero Debugger执行主画面
