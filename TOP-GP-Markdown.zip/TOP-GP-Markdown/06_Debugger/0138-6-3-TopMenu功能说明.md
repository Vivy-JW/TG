---
title: "6.3 TopMenu功能说明"
source: "TOP GP技术手册.pdf#page=169"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明"
type: "concept"
pages: "169"
printed_pages: "160"
---

# 6.3 TopMenu功能说明

## 子主题

- [6.3.1 Run选项](0139-6-3-1-Run选项.md)
- [6.3.2 View选项](0141-6-3-2-View选项.md)
