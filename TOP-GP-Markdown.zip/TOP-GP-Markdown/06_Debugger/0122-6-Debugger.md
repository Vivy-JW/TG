---
title: "6 Debugger"
source: "TOP GP技术手册.pdf#page=164"
breadcrumb: "6 Debugger"
type: "concept"
description: "Genero 语言有提供追踪程序的除错工具（debugger），其中分为文字模式版本（r.d2）以及图形模式版本（r.d2+）。"
pages: "164"
printed_pages: "155"
---

# 6 Debugger

Genero 语言有提供追踪程序的除错工具（debugger），其中分为文字模式版本（r.d2）以及图形模式版本（r.d2+）。以下将对图形模式版本的使用作简单的介绍。

## 子主题

- [6.1 Debugger操作画面](0123-6-1-Debugger操作画面.md)
- [6.2 ToolBar常用功能说明](0127-6-2-ToolBar常用功能说明.md)
- [6.3 TopMenu功能说明](0138-6-3-TopMenu功能说明.md)
