---
title: "6.3.2.7 Watches（Ctrl+W）"
source: "TOP GP技术手册.pdf#page=172"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.7 Watches（Ctrl+W）"
type: "concept"
description: "由TopMenu上的View选项进入Watches。"
pages: "172"
printed_pages: "163"
---

# 6.3.2.7 Watches（Ctrl+W）

由TopMenu上的View选项进入Watches。

设定用户要监看的变量及变量值列表。
