---
title: "6.3.2.5 Global Variables（Ctrl+G）"
source: "TOP GP技术手册.pdf#page=171"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.5 Global Variables（Ctrl+G）"
type: "concept"
description: "由TopMenu上的View选项进入Global Variables。"
pages: "171"
printed_pages: "162"
---

# 6.3.2.5 Global Variables（Ctrl+G）

由TopMenu上的View选项进入Global Variables。这里会列出所有此程序中所有的公用变量及当前的变量值。
