---
title: "6.3.2.4 Functions（Ctrl+U）"
source: "TOP GP技术手册.pdf#page=170"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.4 Functions（Ctrl+U）"
type: "concept"
description: "由TopMenu上的View选项进入Functions。"
pages: "170-171"
printed_pages: "161-162"
---

# 6.3.2.4 Functions（Ctrl+U）

由TopMenu上的View选项进入Functions。这里会列出所有此程序中用到的Function name。

## 图示

![6.3.2.4 Functions（Ctrl+U）（PDF 第 170 页 图 1）](../_images/p0170-02.png)

*图：6.3.2.4 Functions（Ctrl+U），原文 PDF 第 170 页（印刷第 161 页）*

![6.3.2.4 Functions（Ctrl+U）（PDF 第 170 页 图 2）](../_images/p0170-03.png)

*图：6.3.2.4 Functions（Ctrl+U），原文 PDF 第 170 页（印刷第 161 页）*

![6.3.2.4 Functions（Ctrl+U）（PDF 第 170 页 图 3）](../_images/p0170-04.png)

*图：6.3.2.4 Functions（Ctrl+U），原文 PDF 第 170 页（印刷第 161 页）*
