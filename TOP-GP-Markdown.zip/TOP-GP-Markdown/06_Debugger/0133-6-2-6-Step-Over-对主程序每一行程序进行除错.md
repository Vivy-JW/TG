---
title: "6.2.6 Step Over 对主程序每一行程序进行除错"
source: "TOP GP技术手册.pdf#page=167"
breadcrumb: "6 Debugger > 6.2 ToolBar常用功能说明 > 6.2.6 Step Over 对主程序每一行程序进行除错"
type: "concept"
description: "（F10）与Step Into的差别在于碰到子程序段时，不会跳进子程序进行debug，只会将子程序所执行出的结果显示在屏幕上"
pages: "167"
printed_pages: "158"
---

# 6.2.6 Step Over 对主程序每一行程序进行除错

（F10）与Step Into的差别在于碰到子程序段时，不会跳进子程序进行debug，只会将子程序所执行出的结果显示在屏幕上
