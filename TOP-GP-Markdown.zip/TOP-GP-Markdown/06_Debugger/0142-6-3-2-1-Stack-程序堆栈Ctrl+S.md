---
title: "6.3.2.1 Stack 程序堆栈（Ctrl+S）"
source: "TOP GP技术手册.pdf#page=169"
breadcrumb: "6 Debugger > 6.3 TopMenu功能说明 > 6.3.2 View选项 > 6.3.2.1 Stack 程序堆栈（Ctrl+S）"
type: "concept"
description: "由TopMenu上的View选项进入Stack。"
pages: "169"
printed_pages: "160"
---

# 6.3.2.1 Stack 程序堆栈（Ctrl+S）

由TopMenu上的View选项进入Stack。当开始debug时，执行此功能可知道程序阶层状态。例如：当前执行到cl_null()的子程序内，往下的列表会列出cl_null()是由程序中哪个function呼叫的，循序往上推来源function。

## 图示

![6.3.2.1 Stack 程序堆栈（Ctrl+S）（PDF 第 169 页 图 1）](../_images/p0169-02.png)

*图：6.3.2.1 Stack 程序堆栈（Ctrl+S），原文 PDF 第 169 页（印刷第 160 页）*

![6.3.2.1 Stack 程序堆栈（Ctrl+S）（PDF 第 169 页 图 2）](../_images/p0169-03.png)

*图：6.3.2.1 Stack 程序堆栈（Ctrl+S），原文 PDF 第 169 页（印刷第 160 页）*
