---
title: "6.2.5 Step Into 对每一程序行进行除错"
source: "TOP GP技术手册.pdf#page=167"
breadcrumb: "6 Debugger > 6.2 ToolBar常用功能说明 > 6.2.5 Step Into 对每一程序行进行除错"
type: "concept"
description: "（F11）在除错阶段时，此功能会对每一程序行进行追踪，当碰到子程序时，会进到子程序内一行一行除错，直到用户结束此阶段。"
pages: "167"
printed_pages: "158"
---

# 6.2.5 Step Into 对每一程序行进行除错

（F11）在除错阶段时，此功能会对每一程序行进行追踪，当碰到子程序时，会进到子程序内一行一行除错，直到用户结束此阶段。
