---
title: "4.1 Genero Studio 安装及配置"
source: "TOP GP技术手册.pdf#page=63"
breadcrumb: "4 画面档 > 4.1 Genero Studio 安装及配置"
type: "concept"
pages: "63"
printed_pages: "54"
---

# 4.1 Genero Studio 安装及配置

## 子主题

- [4.1.1 Genero Studio 安装](0068-4-1-1-Genero-Studio-安装.md)
- [4.1.2 Genero Studio 配置](0069-4-1-2-Genero-Studio-配置.md)
