---
title: "4.1.2 Genero Studio 配置"
source: "TOP GP技术手册.pdf#page=69"
breadcrumb: "4 画面档 > 4.1 Genero Studio 安装及配置 > 4.1.2 Genero Studio 配置"
type: "concept"
description: "点选Tools-Configurations 测试 GDC 启 2 动 寻找license：echo $FGLPROFILE可获取一个路径/u1/genero/fgl/etc/fglprofile.prod 执行 cd /u1/genero/fgl/etc，打开 fglprofile 文件（注意不是 fglpro..."
pages: "69-75"
printed_pages: "60-66"
---

# 4.1.2 Genero Studio 配置

- 设定GDC目录

点选Tools-Configurations

测试 GDC 启

2 动

- 配置license

寻找license：echo $FGLPROFILE可获取一个路径/u1/genero/fgl/etc/fglprofile.prod

执行 cd /u1/genero/fgl/etc，打开 fglprofile 文件（注意不是 fglprofile.prod），可以查看

License信息。

下载fglprofile文件sz fglprofile，并把该文件覆盖C:\Program Files\FourJs\2.32.24\fgl\etc\fglprofile文件点选Tools-Configurations未设定 License 之前，标志为禁止符号点选GFL 2.32.03，修改FGLDIR目录。按下OK后，可看到2.32.03 DESKTOP变成准许使用符号。

- 调整工作使用语系为UTF-8 TOP GP5.25 预设使用语系（程式及资料）为 UTF-8，此编码适用于多国语系环境。因此建议系统安装时即行调整，以避免开启档案时发生编码异常或无法读取的问题。

点选Tools-Preferences调整完成后，按下右下方的“APPLY”或“OK”即可生效。

## 图示

![4.1.2 Genero Studio 配置（PDF 第 69 页 图 1）](../_images/p0069-02.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 69 页（印刷第 60 页）*

![4.1.2 Genero Studio 配置（PDF 第 69 页 图 2）](../_images/p0069-03.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 69 页（印刷第 60 页）*

![4.1.2 Genero Studio 配置（PDF 第 70 页 图 1）](../_images/p0070-02.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 70 页（印刷第 61 页）*

![4.1.2 Genero Studio 配置（PDF 第 71 页 图 1）](../_images/p0071-02.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 71 页（印刷第 62 页）*

![4.1.2 Genero Studio 配置（PDF 第 71 页 图 2）](../_images/p0071-03.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 71 页（印刷第 62 页）*

![4.1.2 Genero Studio 配置（PDF 第 72 页 图 1）](../_images/p0072-02.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 72 页（印刷第 63 页）*

![4.1.2 Genero Studio 配置（PDF 第 73 页 图 1）](../_images/p0073-02.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 73 页（印刷第 64 页）*

![4.1.2 Genero Studio 配置（PDF 第 74 页 图 1）](../_images/p0074-02.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 74 页（印刷第 65 页）*

![4.1.2 Genero Studio 配置（PDF 第 74 页 图 2）](../_images/p0074-03.png)

*图：4.1.2 Genero Studio 配置，原文 PDF 第 74 页（印刷第 65 页）*
