---
title: "4.1.1 Genero Studio 安装"
source: "TOP GP技术手册.pdf#page=63"
breadcrumb: "4 画面档 > 4.1 Genero Studio 安装及配置 > 4.1.1 Genero Studio 安装"
type: "concept"
description: "Java版本确认 找不到已安装的 Java 时，可点选此 处，安装程式可提 供一个Java安装套 件 如果系统找到，就把它选起来，如果找不到，就选按右侧“INSTALL JVM” 系统准备开始安装"
pages: "63-69"
printed_pages: "54-60"
---

# 4.1.1 Genero Studio 安装

- 确认本机电脑的操作系统平台32位操作系统安装程序：fjs-gst-2.32.24-build101641-w32vc90.exe 64位操作系统安装程序：fjs-gst-2.32.24-build101641-w64vc90.exe安装欢迎画面安装程式检测到系统并未安装 IIS 网页服务系统检测到本机未安装IIS Web Server，建议您应该先安装，以避免ISAPI装置应用有问题，当我们只需要安装成开发环境时，可以不理会此讯息，按OK跳过。安装程式版本宣告Genero版本宣告Workstation or Server预设所有功能都安装Workstation (minimal)只安装Studio Client Server (minimal)只安装Studio Server选择安装为FULL模式。软件是否安装选择由于系统内没有Web Server，因此取消Genero Application Server的安装。安装路径选择此处的安装路径是指前面所选择“整批”软件的安装路径，并非只有Studio这一项的安装路径。个别软件会在此路径下分别设定其自身的子目录，如“fgl”，“gdc”，“gst”等。“程式集”目录名称Genero产品注册页License注册：均取消勾选，因为使用Genero License Server，提供一个共享的License环境，因此本处不进行将License注册于本机的设定。

Java版本确认

找不到已安装的

Java 时，可点选此

处，安装程式可提

供一个Java安装套

件

如果系统找到，就把它选起来，如果找不到，就选按右侧“INSTALL JVM”

系统准备开始安装

**安装完成**

## 图示

![4.1.1 Genero Studio 安装（PDF 第 63 页 图 1）](../_images/p0063-02.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 63 页（印刷第 54 页）*

![4.1.1 Genero Studio 安装（PDF 第 64 页 图 1）](../_images/p0064-02.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 64 页（印刷第 55 页）*

![4.1.1 Genero Studio 安装（PDF 第 64 页 图 2）](../_images/p0064-03.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 64 页（印刷第 55 页）*

![4.1.1 Genero Studio 安装（PDF 第 65 页 图 1）](../_images/p0065-02.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 65 页（印刷第 56 页）*

![4.1.1 Genero Studio 安装（PDF 第 65 页 图 2）](../_images/p0065-03.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 65 页（印刷第 56 页）*

![4.1.1 Genero Studio 安装（PDF 第 66 页 图 1）](../_images/p0066-02.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 66 页（印刷第 57 页）*

![4.1.1 Genero Studio 安装（PDF 第 66 页 图 2）](../_images/p0066-03.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 66 页（印刷第 57 页）*

![4.1.1 Genero Studio 安装（PDF 第 67 页 图 1）](../_images/p0067-02.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 67 页（印刷第 58 页）*

![4.1.1 Genero Studio 安装（PDF 第 67 页 图 2）](../_images/p0067-03.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 67 页（印刷第 58 页）*

![4.1.1 Genero Studio 安装（PDF 第 68 页 图 1）](../_images/p0068-02.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 68 页（印刷第 59 页）*

![4.1.1 Genero Studio 安装（PDF 第 68 页 图 2）](../_images/p0068-03.png)

*图：4.1.1 Genero Studio 安装，原文 PDF 第 68 页（印刷第 59 页）*
