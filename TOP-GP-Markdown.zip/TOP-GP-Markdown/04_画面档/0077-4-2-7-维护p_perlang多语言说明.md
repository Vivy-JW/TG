---
title: "4.2.7 维护p_perlang多语言说明"
source: "TOP GP技术手册.pdf#page=83"
breadcrumb: "4 画面档 > 4.2 画面制作步骤 > 4.2.7 维护p_perlang多语言说明"
type: "concept"
description: "上步骤预览后会自动生成数据到p_perlang(依据p_zta)，只需要修改其中的部分即可。"
pages: "83"
printed_pages: "74"
---

# 4.2.7 维护p_perlang多语言说明

上步骤预览后会自动生成数据到p_perlang(依据p_zta)，只需要修改其中的部分即可。
